These two files can be translated or customized and placed one directory up ( inside the resources folder ) and the script will load them when run.

The script defaults to English and my colour scheme by default.
( these labels and colours are internal and are used if no labels or colours.xml files are found )