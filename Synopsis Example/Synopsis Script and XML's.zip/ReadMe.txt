Ok to use this scrip you need to call it from a button within your Programs window.

You also need to add the skin settings to your skin so you can toggle them.