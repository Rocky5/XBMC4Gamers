import os
import zipfile

def zip_files_in_batches(source_dir, dest_dir, batch_size=2000, compression=zipfile.ZIP_DEFLATED):
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)

    file_list = []
    zip_count = 1

    for root, dirs, files in os.walk(source_dir):
        for file in files:
            file_list.append(os.path.join(root, file))
            if len(file_list) == batch_size:
                first_file = os.path.basename(file_list[0])
                last_file = os.path.basename(file_list[-1])
                zip_filename = os.path.join(dest_dir, 'MilkDrop2 Collection {}-{} ({}).zip'.format(first_file[0], last_file[0], len(file_list)))
                with zipfile.ZipFile(zip_filename, 'w', compression=compression) as zipf:
                    for f in file_list:
                        zipf.write(f, os.path.relpath(f, source_dir))
                file_list = []
                zip_count += 1

    if file_list:
        first_file = os.path.basename(file_list[0])
        last_file = os.path.basename(file_list[-1])
        zip_filename = os.path.join(dest_dir, 'MilkDrop2 Collection {}-{} ({}).zip'.format(first_file[0], last_file[0], len(file_list)))
        with zipfile.ZipFile(zip_filename, 'w', compression=compression) as zipf:
            for f in file_list:
                zipf.write(f, os.path.relpath(f, source_dir))

    print("Total zip files created: {}".format(zip_count))

source_dir = r'MilkDrop Presets\Presets'
dest_dir = r'MilkDrop Presets'
zip_files_in_batches(source_dir, dest_dir)