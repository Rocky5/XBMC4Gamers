import binascii
import os
import shutil
import sys
import xml.etree.ElementTree as ET
from datetime import datetime
from PIL import Image, ImageFilter

def xbe(output_path):
	xbe_data  = binascii.unhexlify('5842454800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000078010100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005644464C00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000')
	destination_path = output_path.replace('_resources', '')
	with open(os.path.join(destination_path, 'default.xbe'), 'wb') as xbe:
		xbe.write(xbe_data)

def resize_image(filename, output_path):
	try:
		img = Image.open(filename)
		if filename.lower().endswith('fanart.jpg'):
			img_resized = img.resize(fanart_size, Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fanart.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((8, 8), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fog.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((220, 124), Image.LANCZOS)
			img_resized = img_resized.filter(ImageFilter.BoxBlur(radius=1.5))
			resized_filename = os.path.join(output_path, f'fanart-blur.jpg')
			img_resized.save(resized_filename)
			
		if filename.lower().endswith('thumb.jpg'):
			img_resized = img.resize((360, 203), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fanart_thumb.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((227, 129), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'thumb.jpg')
			img_resized.save(resized_filename)
			
		
		if filename.lower().endswith('poster.jpg'):
			img_resized = img.resize((362, 512), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'synopsis.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((362, 512), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'alt_synopsis.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((200, 283), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'poster.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((64, 91), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'poster_small.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img_resized.filter(ImageFilter.BoxBlur(radius=1.5))
			resized_filename = os.path.join(output_path, f'poster_small_blurred.jpg')
			img_resized.save(resized_filename)
		
		if filename.lower().endswith('folder.jpg'):
			img_resized = img.resize((362, 512), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'synopsis.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((362, 512), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'alt_synopsis.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((200, 283), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'poster.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((64, 91), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'poster_small.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img_resized.filter(ImageFilter.BoxBlur(radius=1.5))
			resized_filename = os.path.join(output_path, f'poster_small_blurred.jpg')
			img_resized.save(resized_filename)
		
		destination_path = output_path.replace('_resources\\artwork', '')
		if filename.lower().endswith('fanart.jpg'):
			shutil.copyfile(os.path.join(output_path, f'fanart.jpg'), os.path.join(destination_path, 'fanart.jpg'))
		if filename.lower().endswith('poster.jpg'):
			shutil.copyfile(os.path.join(output_path, f'poster.jpg'), os.path.join(destination_path, 'default.tbn'))
		if filename.lower().endswith('thumb.jpg'):
			shutil.copyfile(os.path.join(output_path, f'poster.jpg'), os.path.join(destination_path, 'default.tbn'))
			
		return resized_filename
	except:
		return ''

def resize_image_alt(filename, output_path):
	try:
		img = Image.open(filename)
		img_resized = img.resize((200, 283), Image.LANCZOS)
		resized_filename = os.path.join(output_path, 'folder.jpg')
		img_resized.save(resized_filename)
		return resized_filename
	except:
		return ''

def copy_video(folder_path, output_path, strm_mode, episode, output_video_path):
	video_files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
	for video in video_files:
		name, file_extension = os.path.splitext(video)
		if file_extension.lower() in target_extensions:
			destination_path = output_path.replace('_resources', '')
			if name.startswith(episode):
				if strm_mode == '':
					shutil.copyfile(os.path.join(folder_path, video), os.path.join(destination_path, video))
				else:
					with open(os.path.join(destination_path, name + '.strm'), 'w') as strm:
						strm.write(strm_mode + output_video_path + file_extension )
		
def check_text(input, tag):
	try:
		if tag == 'aired':
			return input.find('aired').text
		if tag == 'rating':
			try:
				return input.find(tag).text
			except AttributeError:
				return input.find(f'.//{tag}[@name="tvdb"]/value').text
		elif tag == 'credits':
			return [credits.text for credits in input.findall(tag)]
		else:
			return input.find(tag).text
	except AttributeError:
		return ''

def process_folder(folder_path, root_folder):
	
	print(f'Processing:\n  {os.path.basename(folder_path)}')
	
	root = 'Xbox'
	output_path_images = os.path.join(root, root_folder, os.path.basename(folder_path))
	if not os.path.isdir(output_path_images):
		os.makedirs(output_path_images)

	nfo_file = None
	image_filenames = []
	for root, _, files in os.walk(folder_path):
		for filename in files:
			if not 'season' in root.lower() or 'series' in root.lower():
				full_path = os.path.join(root, filename)
				if filename.lower().endswith('.nfo'):
					nfo_file = full_path
				elif filename.lower().endswith('folder.jpg'):
					image_filenames.append(full_path)

		# print(output_path_images)
		# print('Images resized and saved.')
		
		# Resize alt images
		resized_image_filenames = []
		for image_filename in image_filenames:
			resized_image_filenames.append(resize_image_alt(image_filename, output_path_images))

def process_season_folder(folder_path, root_folder, strm_mode, show_folder, parent):
	
	print(f'   - {os.path.basename(folder_path)}')
	
	root = 'Xbox'
	output_path_images = os.path.join(root, root_folder, parent, os.path.basename(folder_path))

	if not os.path.isdir(output_path_images):
		os.makedirs(output_path_images)

	image_extensions = ('poster.jpg')
	image_filenames = []
	
	season_numb = os.path.basename(folder_path).split(' ')[1]
	season = os.path.basename(folder_path)
	
	if len(season_numb) > 1 and not season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
	
	elif len(season_numb) > 1 and season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
			
	elif len(season_numb) == 1:
		season = f'season{season_numb.zfill(2)}'
		if season_numb == '0':
			season = f'season-specials'

	found = 0
	for root, _, files in os.walk(show_folder):
		for filename in files:
			full_path = os.path.join(root, filename)
			if not found and filename.lower() == 'folder.jpg':
				found = 1
				if os.path.isfile(os.path.join(root, filename)):
					full_path = os.path.join(root, filename)
					image_filenames.append(full_path)
			if filename.lower().endswith(image_extensions):
				filename = f'{season}-poster.jpg'
				if season.lower() in filename.lower():
					if os.path.isfile(os.path.join(root, filename)):
						full_path = os.path.join(root, filename)
						image_filenames.append(full_path)

		# print(output_path_images)
		# print('Images resized and saved.')
		
		# Resize alt images
		resized_image_filenames = []
		for image_filename in image_filenames:
			resized_image_filenames.append(resize_image_alt(image_filename, output_path_images))
		
def process_episode_folder(folder_path, root_folder, strm_mode, show_folder, parent, episode):
	episode_filename = episode
	root = 'Xbox'
	output_path_images = os.path.join(root, root_folder, parent, os.path.basename(folder_path), episode_filename.replace('.', ''), '_resources\\artwork')
	output_path = os.path.join(root, root_folder, parent, os.path.basename(folder_path), episode_filename.replace('.', ''), '_resources')
	output_video_path = os.path.join(parent, os.path.basename(folder_path), episode_filename)
	
	if not os.path.isdir(output_path_images):
		os.makedirs(output_path_images)

	nfo_file = None
	image_filenames = []
	for root, _, files in os.walk(folder_path):
		for filename in files:
			full_path = os.path.join(root, filename)
			if filename.lower().endswith('.nfo') and filename.startswith(episode_filename):
				nfo_file = full_path
	
	season_numb = os.path.basename(folder_path).split(' ')[1]
	season = os.path.basename(folder_path)
	
	if len(season_numb) > 1 and not season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
	
	elif len(season_numb) > 1 and season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
			
	elif len(season_numb) == 1:
		season = f'season{season_numb.zfill(2)}'
		if season_numb == '0':
			season = f'season-specials'
	
	found = 0
	for root, _, files in os.walk(show_folder):
		for filename in files:
			full_path = os.path.join(root, filename)
			if filename.lower().endswith('thumb.jpg'):
				filename = f'{episode_filename}-thumb.jpg'
				if episode_filename.lower() in filename.lower():
					if os.path.isfile(os.path.join(root, filename)):
						full_path = os.path.join(root, filename)
						image_filenames.append(full_path)
			
			if filename.lower().endswith('fanart.jpg'):
				full_path = os.path.join(root, filename)
				image_filenames.append(full_path)
			
			if not found and filename.lower() == 'folder.jpg':
				found = 1
				if os.path.isfile(os.path.join(root, filename)):
					full_path = os.path.join(root, filename)
					image_filenames.append(full_path)
			
			if filename.lower().endswith('poster.jpg'):
				filename = f'{season}-poster.jpg'
				if season.lower() in filename.lower():
					if os.path.isfile(os.path.join(root, filename)):
						full_path = os.path.join(root, filename)
						image_filenames.append(full_path)

	if nfo_file:
		with open(nfo_file, 'r', encoding='utf-8') as xml_file:
			xml_data = xml_file.read()

		# Parse XML data
		xml_string = xml_data.replace("&", "&amp;")
		all_episode_details = ET.fromstring(xml_string).findall(".//episodedetails")
		try:
			tags = all_episode_details[0]
		except:
			tags = ET.fromstring(xml_string)
		director = check_text(tags, 'director')
		credits = check_text(tags, 'credits')
		if director.strip() != '' and credits != '':
			credits.insert(0, director)
			director = ', '.join(credits)
		imdb_rating = check_text(tags, 'rating')
		mpaa = check_text(tags, 'mpaa')
		plot = check_text(tags, 'plot')
		premiered = check_text(tags, 'premiered')
		if not premiered:
			premiered = check_text(tags, 'aired')
		runtime = check_text(tags, 'runtime')
		season = check_text(tags, 'season')
		episode = check_text(tags, 'episode')
		title = check_text(tags, 'title')
		year = check_text(tags, 'year')
		if not year:
			try:
				year = datetime.strptime(premiered, '%Y-%m-%d').strftime('%Y')
			except:
				pass
		features_general = runtime

		# Format date
		try:
			premiered_date = datetime.strptime(premiered, '%Y-%m-%d')
			formatted_premiered = premiered_date.strftime('%d %b %Y')
		except ValueError:
			formatted_premiered = premiered

		synopsis = ET.Element('synopsis')
		ET.SubElement(synopsis, 'sourcename')
		ET.SubElement(synopsis, 'foldername')
		ET.SubElement(synopsis, 'title').text = f'{episode_filename.split('-')[0].replace(' ','')}: {title}'
		ET.SubElement(synopsis, 'developer')
		ET.SubElement(synopsis, 'publisher')
		ET.SubElement(synopsis, 'features_general').text = features_general
		ET.SubElement(synopsis, 'features_online')
		ET.SubElement(synopsis, 'esrb').text = mpaa
		ET.SubElement(synopsis, 'esrb_descriptors')
		ET.SubElement(synopsis, 'genre').text = director.strip()
		ET.SubElement(synopsis, 'release_date').text = formatted_premiered
		ET.SubElement(synopsis, 'year').text = year
		ET.SubElement(synopsis, 'rating').text = imdb_rating
		ET.SubElement(synopsis, 'platform')
		ET.SubElement(synopsis, 'exclusive')
		ET.SubElement(synopsis, 'titleid')
		ET.SubElement(synopsis, 'overview').text = plot.strip()

		tree = ET.ElementTree(synopsis)
		base_path, _ = os.path.split(nfo_file)
		output_file_path = os.path.join(output_path, f'default.xml')
		tree.write(output_file_path, encoding='utf-8', xml_declaration=True, method='xml', short_empty_elements=False)

		# Resize images
		resized_image_filenames = []
		for image_filename in image_filenames:
			resized_image_filenames.append(resize_image(image_filename, output_path_images))
		
		copy_video(folder_path, output_path, strm_mode, episode_filename, output_video_path)
		
		xbe(output_path)

		# print(output_file_path)
		# print('Images resized and saved.')
		
def read_settings(file_path):
	settings = {}
	with open(file_path, 'r') as file:
		for line in file:
			if line.strip() and not line.startswith('#') and '=' in line:
				key, value = line.split('=', 1)
				settings[key.strip()] = value.strip()
	return settings

def set_window_size(title, color='00', width=100, height=100):
	if os.name == 'nt':
		os.system('mode con: cols={} lines={}'.format(width, height))
		os.system('title {}'.format(title))
		os.system('color {}'.format(color))

def main():	
	version = 1.0
	set_window_size('PC TV Shows to Xbox files v{}'.format(version), '0B', 70, 11)
	
	# Check for settings.ini and make one if it doesn't exist
	if not os.path.isfile('settings_tv_shows.ini'):
		settings_template = '''[Settings]
root_folder=TV Shows
;128MB needed for large collections
better_fanart=false
[SMB]
use_smb=false
username=
password=
sym_folder=SMB_Movies
smb_path=ROUTER\\TV Shows'''
		with open('settings_tv_shows.ini', 'w') as settings:
			settings.write(settings_template)
		sys.exit()
	
	# Read settings
	settings = read_settings('settings_tv_shows.ini')
	root_folder = settings.get('root_folder')
	better_fanart = settings.get('better_fanart')
	smb_enabled = settings.get('use_smb')
	smb_path = settings.get('smb_path')
	sym_folder = settings.get('sym_folder')
	smb_user = settings.get('username')
	smb_pass = settings.get('password')
	
	global fanart_size
	if better_fanart.lower() in ['1', 'yes', 'true']:
		fanart_size = (853, 480)
	else:
		fanart_size = (640, 360)
	
	global target_extensions
	target_extensions = ['.m4v', '.3gp', '.nsv', '.ts', '.ty', '.strm', '.rm', '.rmvb', '.m3u', '.ifo', '.mov', '.qt', '.divx', '.xvid', '.bivx', '.vob', '.nrg', '.img', '.iso', '.pva', '.wmv', '.asf', '.asx', '.ogm', '.m2v', '.avi', '.bin', '.dat', '.dvr-ms', '.mpg', '.mpeg', '.mp4', '.mkv', '.avc', '.vp3', '.svq3', '.nuv', '.viv', '.dv', '.fli', '.flv', '.rar', '.001', '.wpl', '.zip']
	
	strm_mode = ''
	if smb_enabled.lower() in ['1', 'yes', 'true']:
		strm_mode = f'smb://{smb_user}:{smb_pass}@{smb_path}\\'
		
		if not smb_path.startswith('\\'):
			smb_path = '\\\\' + smb_path
		
		sym_link = f'mklink /D "{sym_folder}" "{smb_path}"'
		if not os.path.isdir(sym_folder):
			os.system(f'cmd /c {sym_link}')

	parent = ''
	show_folder = ''
	for dirpath in os.listdir(root_folder):
		
		if os.path.isdir(os.path.join(root_folder, dirpath)):
		
			folder_path = os.path.join(root_folder, dirpath)
			
			parent = dirpath
			show_folder = folder_path
			process_folder(folder_path, root_folder)
		
			for dirname in sorted(os.listdir(folder_path)):
				
				folder_path = os.path.join(root_folder, dirpath, dirname)
				
				if os.path.isdir(folder_path):
					
					if dirname.lower().startswith('season') or dirname.lower().startswith('series'):
						process_season_folder(folder_path, root_folder, strm_mode, show_folder, parent)
						video_files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
						for video in video_files:
							episode, file_extension = os.path.splitext(video)
							if file_extension.lower() in target_extensions:
								process_episode_folder(folder_path, root_folder, strm_mode, show_folder, parent, episode)

if __name__ == '__main__':
	main()
