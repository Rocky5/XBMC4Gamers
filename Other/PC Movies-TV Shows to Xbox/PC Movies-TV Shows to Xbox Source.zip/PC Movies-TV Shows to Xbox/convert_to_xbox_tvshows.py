import sys
import os
import subprocess

required_packages = ['imageio', 'imageio-ffmpeg', 'av', 'Pillow']

def install_package(package):
	""" Install a package silently, handling errors. """
	try:
		with open(os.devnull, 'w') as devnull:
			subprocess.check_call([sys.executable, '-m', 'pip', 'install', package], stdout=devnull, stderr=devnull)
	except subprocess.CalledProcessError as e:
		print(f"Error installing {package}: {e}")

for package in required_packages:
	try:
		__import__(package.replace("-", "_"))
	except ImportError:
		install_package(package)

import imageio
import imageio_ffmpeg

try:
	pass
	# print(f"FFmpeg version: {imageio_ffmpeg.get_ffmpeg_version()}")
except Exception as e:
	print(f"Error: FFmpeg plugin not found or failed to install: {e}")

import binascii
import random
import re
import shutil
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime
from PIL import Image, ImageFilter

def xbe(output_path):
	xbe_data  = binascii.unhexlify('5842454800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000078010100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005644464C00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000')
	destination_path = output_path.replace('_resources', '')
	with open(os.path.join(destination_path, 'default.xbe'), 'wb') as xbe:
		xbe.write(xbe_data)

def resize_image(filename, output_path):
	try:
		img = Image.open(filename)
		if filename.lower().endswith('fanart.jpg'):
			img_resized = img.resize(fanart_size, Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fanart.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((360, 203), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fanart_thumb.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((227, 129), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'thumb.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((8, 8), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fog.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((220, 124), Image.LANCZOS)
			img_resized = img_resized.filter(ImageFilter.BoxBlur(radius=1.5))
			resized_filename = os.path.join(output_path, f'fanart-blur.jpg')
			img_resized.save(resized_filename)
			
		if filename.lower().endswith('screenshot-1.jpg'):
			img_resized = img.resize((227, 129), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'thumb.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((360, 203), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'fanart_thumb.jpg')
			img_resized.save(resized_filename)
		
		if filename.lower().endswith('poster.jpg'):
			img_resized = img.resize((200, 283), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'poster.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((64, 91), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'poster_small.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img_resized.filter(ImageFilter.BoxBlur(radius=1.5))
			resized_filename = os.path.join(output_path, f'poster_small_blurred.jpg')
			img_resized.save(resized_filename)
			
			img_resized = img.resize((362, 512), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'synopsis.jpg')
			img_resized.save(resized_filename)
		
		if filename.lower().endswith('folder.jpg'):
			img_resized = img.resize((362, 512), Image.LANCZOS)
			resized_filename = os.path.join(output_path, f'alt_synopsis.jpg')
			img_resized.save(resized_filename)
		
		destination_path = output_path.replace('_resources\\artwork', '')
		if filename.lower().endswith('fanart.jpg'):
			shutil.copyfile(os.path.join(output_path, f'fanart.jpg'), os.path.join(destination_path, 'fanart.jpg'))
		if filename.lower().endswith('poster.jpg'):
			shutil.copyfile(os.path.join(output_path, f'poster.jpg'), os.path.join(destination_path, 'default.tbn'))
		if filename.lower().endswith('thumb.jpg'):
			shutil.copyfile(os.path.join(output_path, f'poster.jpg'), os.path.join(destination_path, 'default.tbn'))
			
		return resized_filename
	except:
		return ''

def resize_image_alt(filename, output_path):
	try:
		img = Image.open(filename)
		img_resized = img.resize((200, 283), Image.LANCZOS)
		resized_filename = os.path.join(output_path, 'folder.jpg')
		img_resized.save(resized_filename)
		return resized_filename
	except:
		return ''

def resize_screenshots(input_path, output_path, target_size=(512, 288)):
	image = Image.open(input_path)
	image.thumbnail(target_size, Image.Resampling.LANCZOS)
	image.save(output_path, "JPEG")

def copy_video(folder_path, output_path, strm_mode, episode, output_video_path):
	destination_path = output_path.replace('_resources', '')
	screenshots_path = os.path.join(output_path, "screenshots")
	os.makedirs(screenshots_path, exist_ok=True)

	for entry in os.scandir(folder_path):
		if entry.is_file():
			name, file_extension = os.path.splitext(entry.name)
			if file_extension.lower() in target_extensions and sanitize_name(name).startswith(sanitize_name(episode)):
				video_path = entry.path
				
				sanitized_video_name = sanitize_filename(entry.name)
				sanitized_strm_name = sanitize_filename(f"{name}.strm")

				if not strm_mode:
					shutil.copyfile(video_path, os.path.join(destination_path, sanitized_video_name))
				else:
					strm_file = os.path.join(destination_path, sanitized_strm_name)
					with open(strm_file, 'w') as strm:
						strm.write(f"{strm_mode}{output_video_path}{file_extension}")

				try:
					reader = imageio.get_reader(video_path, format="FFMPEG")
					meta = reader.get_meta_data()
					fps = meta.get("fps", 30)
					duration = meta.get("duration", 600)

					hardcoded_timestamps = [180, 360, 600]  # 3 mins, 6 mins, 10 mins in seconds
					valid_timestamps = [t for t in hardcoded_timestamps if t < duration]

					if len(valid_timestamps) < len(hardcoded_timestamps):
						valid_timestamps = [random.uniform(0, min(duration, 600)) for _ in range(3)]

					for i, timestamp in enumerate(valid_timestamps, start=1):
						frame_idx = int(timestamp * fps)
						try:
							frame = reader.get_data(frame_idx)
							output_filename = os.path.join(screenshots_path, f"Screenshot-{i}.jpg")
							imageio.imwrite(output_filename, frame)

							resize_screenshots(output_filename, output_filename)

							output_path_images = os.path.join(output_path, "artwork")
							resize_image(os.path.join(screenshots_path, "Screenshot-1.jpg"), output_path_images)

						except IndexError:
							pass

				except Exception as e:
					pass

				finally:
					if 'reader' in locals():
						reader.close()
		
def check_text(input, tag):
	try:
		if tag == 'aired':
			return input.find('aired').text
		if tag == 'rating':
			try:
				return input.find(tag).text
			except AttributeError:
				return input.find(f'.//{tag}[@name="tvdb"]/value').text
		elif tag == 'director':
			return [director.text for director in input.findall(tag)]
		elif tag == 'credits':
			return [credits.text for credits in input.findall(tag)]
		else:
			return input.find(tag).text
	except AttributeError:
		return ''

def sanitize_name(name, max_length=42):
	name = name.strip().replace(",", "")
	name = unicodedata.normalize("NFKD", name).encode("ASCII", "ignore").decode("ASCII")
	name = re.sub(r"[^ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&'()-.@[\]^_`{}~ ]", "", name)
	name = re.sub(r"\.{2,}", ".", name)
	name = re.sub(r"\.$", "", name)
	name = name.rstrip(" -_")
	return name[:max_length]

def sanitize_filename(filename, max_length=42):
	name, ext = os.path.splitext(filename)
	max_name_length = max_length - len(ext)
	sanitized_name = sanitize_name(name, max_name_length)
	return sanitized_name + ext

def process_folder(folder_path, root_folder):
	sanitized_folder = sanitize_name(os.path.basename(folder_path))
	
	print(f'\n  Processing: {os.path.basename(folder_path)}')

	root = 'Xbox'
	output_path_images = os.path.join(root, root_folder, sanitized_folder)

	# Skip processing if the output folder already exists
	if os.path.exists(output_path_images):
		print(f"Skipping {folder_path}, output folder already exists.")
		return

	os.makedirs(output_path_images, exist_ok=True)

	nfo_file = None
	image_filenames = []
	for root, _, files in os.walk(folder_path):
		for filename in files:
			sanitized_filename = sanitize_filename(filename)
			if not 'season' in root.lower() or 'series' in root.lower():
				full_path = os.path.join(root, sanitized_filename)
				if filename.lower().endswith('.nfo'):
					nfo_file = full_path
				elif filename.lower().endswith('folder.jpg'):
					image_filenames.append(full_path)

	resized_image_filenames = [resize_image_alt(img, output_path_images) for img in image_filenames]

def process_season_folder(folder_path, root_folder, strm_mode, show_folder, parent):
	sanitized_folder = sanitize_name(os.path.basename(folder_path))
	
	print(f'   - {os.path.basename(folder_path)}')

	root = 'Xbox'
	output_path_images = os.path.join(root, root_folder, parent, sanitized_folder)

	# Skip processing if the output folder already exists
	if os.path.exists(output_path_images):
		print(f"Skipping {folder_path}, output folder already exists.")
		return

	os.makedirs(output_path_images, exist_ok=True)

	image_extensions = ('poster.jpg')
	image_filenames = []
	
	season_numb = os.path.basename(folder_path).split(' ')[1]
	season = os.path.basename(folder_path)
	
	if len(season_numb) > 1 and not season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
	
	elif len(season_numb) > 1 and season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
			
	elif len(season_numb) == 1:
		season = f'season{season_numb.zfill(2)}'
		if season_numb == '0':
			season = f'season-specials'

	found = 0
	for root, _, files in os.walk(show_folder):
		for filename in files:
			full_path = os.path.join(root, filename)
			if not found and filename.lower() == 'folder.jpg':
				found = 1
				if os.path.isfile(os.path.join(root, filename)):
					full_path = os.path.join(root, filename)
					image_filenames.append(full_path)
			if filename.lower().endswith(image_extensions):
				filename = f'{season}-poster.jpg'
				if season.lower() in filename.lower():
					if os.path.isfile(os.path.join(root, filename)):
						full_path = os.path.join(root, filename)
						image_filenames.append(full_path)

		# print(output_path_images)
		# print('Images resized and saved.')
		
		# Resize alt images
		resized_image_filenames = []
		for image_filename in image_filenames:
			resized_image_filenames.append(resize_image_alt(image_filename, output_path_images))
		
def process_episode_folder(folder_path, root_folder, strm_mode, show_folder, parent, episode):
	sanitized_episode = sanitize_name(episode).strip()
	sanitized_folder = sanitize_name(os.path.basename(folder_path)).strip()
	
	print(f'     - {episode}')

	root = 'Xbox'
	output_path = os.path.join("Xbox", root_folder, parent, sanitized_folder, sanitized_episode, "_resources")
	output_path_images = os.path.join(output_path, "artwork")
	output_video_path = os.path.join(parent, sanitized_folder, sanitized_episode)

	# Skip processing if the output folder already exists
	if os.path.exists(output_path):
		print(f"Skipping {sanitized_episode}, output folder already exists.")
		return

	os.makedirs(os.path.dirname(output_path), exist_ok=True)
	os.makedirs(output_path_images, exist_ok=True)

	nfo_file = None
	image_filenames = []
	episode_filename = sanitize_name(episode)
	for root, _, files in os.walk(folder_path):
		for filename in files:
			full_path = os.path.join(root, filename)
			if filename.lower().endswith('.nfo') and sanitize_name(filename).startswith(episode_filename):
				nfo_file = full_path


	# Extract season number
	season_numb = os.path.basename(folder_path).split(' ')[1]
	season = os.path.basename(folder_path)

	if len(season_numb) > 1 and not season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
	elif len(season_numb) > 1 and season_numb.startswith('0'):
		season = f'season{season_numb}'
		if season_numb == '00':
			season = f'season-specials'
	elif len(season_numb) == 1:
		season = f'season{season_numb.zfill(2)}'
		if season_numb == '0':
			season = f'season-specials'

	found = 0
	for root, _, files in os.walk(show_folder):
		for filename in files:
			full_path = os.path.join(root, filename)
			if filename.lower().endswith('thumb.jpg'):
				filename = f'{episode_filename}-thumb.jpg'
				if episode_filename.lower() in filename.lower():
					if os.path.isfile(os.path.join(root, filename)):
						full_path = os.path.join(root, filename)
						image_filenames.append(full_path)

			if filename.lower().endswith('fanart.jpg'):
				full_path = os.path.join(root, filename)
				image_filenames.append(full_path)

			if not found and filename.lower() == 'folder.jpg':
				found = 1
				if os.path.isfile(os.path.join(root, filename)):
					full_path = os.path.join(root, filename)
					image_filenames.append(full_path)

			if filename.lower().endswith('poster.jpg'):
				filename = f'{season}-poster.jpg'
				if season.lower() in filename.lower():
					if os.path.isfile(os.path.join(root, filename)):
						full_path = os.path.join(root, filename)
						image_filenames.append(full_path)

	if nfo_file:
		with open(nfo_file, 'r', encoding='utf-8') as xml_file:
			xml_data = xml_file.read()

		xml_string = xml_data.replace("&", "&amp;")
		all_episode_details = ET.fromstring(xml_string).findall(".//episodedetails")
		try:
			tags = all_episode_details[0]
		except:
			tags = ET.fromstring(xml_string)

		director = check_text(tags, 'director')
		credits = check_text(tags, 'credits')
		imdb_rating = check_text(tags, 'rating')
		mpaa = check_text(tags, 'mpaa')
		plot = check_text(tags, 'plot')
		premiered = check_text(tags, 'premiered')
		if not premiered:
			premiered = check_text(tags, 'aired')
		runtime = check_text(tags, 'runtime')
		season = check_text(tags, 'season')
		episode = check_text(tags, 'episode')
		title = check_text(tags, 'title')
		year = check_text(tags, 'year')
		if not year:
			try:
				year = datetime.strptime(premiered, '%Y-%m-%d').strftime('%Y')
			except:
				pass
		features_general = f"Runtime: {runtime}"

		# Format date
		try:
			premiered_date = datetime.strptime(premiered, '%Y-%m-%d')
			formatted_premiered = premiered_date.strftime('%d %b %Y')
		except ValueError:
			formatted_premiered = premiered

		synopsis = ET.Element('synopsis')
		ET.SubElement(synopsis, 'title').text = f'{episode_filename.split("-")[0].replace(" ", "")}: {title}'
		ET.SubElement(synopsis, 'developer').text = ' / '.join(director)
		ET.SubElement(synopsis, 'features_general').text = features_general
		ET.SubElement(synopsis, 'esrb').text = mpaa
		ET.SubElement(synopsis, 'genre').text = ' / '.join(credits)
		ET.SubElement(synopsis, 'release_date').text = formatted_premiered
		ET.SubElement(synopsis, 'year').text = year
		ET.SubElement(synopsis, 'rating').text = imdb_rating
		ET.SubElement(synopsis, 'overview').text = plot.strip()

		tree = ET.ElementTree(synopsis)
		base_path, _ = os.path.split(nfo_file)
		output_file_path = os.path.join(output_path, 'default.xml')
		tree.write(output_file_path, encoding='utf-8', xml_declaration=False)

		# Resize images
		resized_image_filenames = []
		for image_filename in image_filenames:
			resized_image_filenames.append(resize_image(image_filename, output_path_images))

		copy_video(folder_path, output_path, strm_mode, episode_filename, output_video_path)

		xbe(output_path)
		
def read_settings(file_path):
	settings = {}
	with open(file_path, 'r') as file:
		for line in file:
			if line.strip() and not line.startswith('#') and '=' in line:
				key, value = line.split('=', 1)
				settings[key.strip()] = value.strip()
	return settings

def set_window_size(title, color='00', width=100, height=100):
	if os.name == 'nt':
		os.system('mode con: cols={} lines={}'.format(width, height))
		os.system('title {}'.format(title))
		os.system('color {}'.format(color))

def main():
	version = 1.1
	set_window_size('PC TV Shows to Xbox files v{}'.format(version), '0B', 70, 20)

	# Check for settings.ini and make one if it doesn't exist
	if not os.path.isfile('settings_tv_shows.ini'):
		settings_template = '''[Settings]
root_folder=TV Shows
;128MB needed for large collections
better_fanart=false
[SMB]
use_smb=false
username=
password=
sym_folder=SMB_Movies
smb_path=ROUTER\\TV Shows'''
		with open('settings_tv_shows.ini', 'w') as settings:
			settings.write(settings_template)
		sys.exit()
	
	# Read settings
	settings = read_settings('settings_tv_shows.ini')
	root_folder = settings.get('root_folder')
	better_fanart = settings.get('better_fanart')
	smb_enabled = settings.get('use_smb')
	smb_path = settings.get('smb_path')
	sym_folder = settings.get('sym_folder')
	smb_user = settings.get('username')
	smb_pass = settings.get('password')
	
	global fanart_size
	if better_fanart.lower() in ['1', 'yes', 'true']:
		fanart_size = (853, 480)
	else:
		fanart_size = (640, 360)
	
	global target_extensions
	target_extensions = {'.m4v', '.3gp', '.nsv', '.ts', '.ty', '.strm', '.rm', '.rmvb', '.m3u', '.ifo', '.mov', '.qt',
						 '.divx', '.xvid', '.bivx', '.vob', '.nrg', '.img', '.iso', '.pva', '.wmv', '.asf', '.asx',
						 '.ogm', '.m2v', '.avi', '.bin', '.dat', '.dvr-ms', '.mpg', '.mpeg', '.mp4', '.mkv', '.avc',
						 '.vp3', '.svq3', '.nuv', '.viv', '.dv', '.fli', '.flv', '.rar', '.001', '.wpl', '.zip'}
	strm_mode = ''
	if smb_enabled.lower() in ['1', 'yes', 'true']:
		strm_mode = f'smb://{smb_user}:{smb_pass}@{smb_path}\\'
		
		if not smb_path.startswith('\\'):
			smb_path = '\\\\' + smb_path
		
		sym_link = f'mklink /D "{sym_folder}" "{smb_path}"'
		if not os.path.isdir(sym_folder):
			os.system(f'cmd /c {sym_link}')

	parent = ''
	show_folder = ''
	for dirpath in os.listdir(root_folder):
		
		if os.path.isdir(os.path.join(root_folder, dirpath)):
		
			folder_path = os.path.join(root_folder, dirpath)
			
			parent = dirpath
			show_folder = folder_path
			process_folder(folder_path, root_folder)
		
			for dirname in sorted(os.listdir(folder_path)):
				
				folder_path = os.path.join(root_folder, dirpath, dirname)
				
				if os.path.isdir(folder_path):
					
					if dirname.lower().startswith('season') or dirname.lower().startswith('series'):
						process_season_folder(folder_path, root_folder, strm_mode, show_folder, parent)
						video_files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
						for video in video_files:
							episode, file_extension = os.path.splitext(video)
							if file_extension.lower() in target_extensions:
								process_episode_folder(folder_path, root_folder, strm_mode, show_folder, parent, episode)

if __name__ == '__main__':
	main()
